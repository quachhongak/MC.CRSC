import { ICrscPrompt } from '../models/ICrscPrompt';
export declare type IPromptSortOrder = 'newest' | 'oldest' | 'aToZ' | 'zToA';
export declare function filterAndSortPrompts(prompts: ICrscPrompt[], query: string, deliverable: string, category: string, sortOrder: IPromptSortOrder): ICrscPrompt[];
export declare function formatModifiedDate(value: string): string;
//# sourceMappingURL=promptUtils.d.ts.map
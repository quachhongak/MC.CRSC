import { ICrscPrompt, IListOption } from '../models/ICrscPrompt';
import { ISharePointService } from './ISharePointService';
export default class MockSharePointService implements ISharePointService {
    getLists(): Promise<IListOption[]>;
    getPrompts(_listId: string): Promise<ICrscPrompt[]>;
}
//# sourceMappingURL=MockSharePointService.d.ts.map
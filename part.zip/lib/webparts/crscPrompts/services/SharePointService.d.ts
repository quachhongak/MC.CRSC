import { SPFI } from '@pnp/sp';
import '@pnp/sp/webs';
import '@pnp/sp/lists';
import '@pnp/sp/items';
import { ICrscPrompt, IListOption } from '../models/ICrscPrompt';
import { ISharePointService } from './ISharePointService';
export default class SharePointService implements ISharePointService {
    private readonly sp;
    constructor(sp: SPFI);
    getLists(): Promise<IListOption[]>;
    getPrompts(listId: string): Promise<ICrscPrompt[]>;
}
//# sourceMappingURL=SharePointService.d.ts.map
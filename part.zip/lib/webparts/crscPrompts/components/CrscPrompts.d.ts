import * as React from "react";
import { ICrscPrompt } from "../models/ICrscPrompt";
import { IPromptSortOrder } from "../utils/promptUtils";
import { ICrscPromptsProps } from "./ICrscPromptsProps";
interface ICrscPromptsState {
    prompts: ICrscPrompt[];
    loading: boolean;
    error?: string;
    query: string;
    deliverable: string;
    category: string;
    sortOrder: IPromptSortOrder;
    page: number;
    selectedPrompt?: ICrscPrompt;
}
export default class CrscPrompts extends React.Component<ICrscPromptsProps, ICrscPromptsState> {
    constructor(props: ICrscPromptsProps);
    componentDidMount(): void;
    componentDidUpdate(previousProps: ICrscPromptsProps): void;
    private loadPrompts;
    private onSearch;
    private onDeliverableChange;
    private onCategoryChange;
    private onSortChange;
    private clearFilters;
    private renderPromptDetails;
    render(): React.ReactElement<ICrscPromptsProps>;
}
export {};
//# sourceMappingURL=CrscPrompts.d.ts.map
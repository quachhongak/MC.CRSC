import * as React from 'react';
interface ICrscPromptsErrorBoundaryState {
    hasError: boolean;
}
export default class CrscPromptsErrorBoundary extends React.Component<React.PropsWithChildren<{}>, ICrscPromptsErrorBoundaryState> {
    state: ICrscPromptsErrorBoundaryState;
    static getDerivedStateFromError(): ICrscPromptsErrorBoundaryState;
    componentDidCatch(error: Error): void;
    render(): React.ReactNode;
}
export {};
//# sourceMappingURL=CrscPromptsErrorBoundary.d.ts.map
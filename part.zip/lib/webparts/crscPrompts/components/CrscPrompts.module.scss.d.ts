declare const styles: {
    crscPrompts: string;
    filterPanel: string;
    searchRow: string;
    filterRow: string;
    resultsBar: string;
    pagination: string;
    searchBox: string;
    filtersLabel: string;
    filterDropdown: string;
    sortGroup: string;
    sortDropdown: string;
    bottomPagination: string;
    pageButton: string;
    promptGrid: string;
    promptCard: string;
    deliverableTag: string;
    promptTitle: string;
    promptContent: string;
    paddingBottomMedium: string;
    viewButton: string;
    configureButton: string;
    statusMessage: string;
    promptDetails: string;
    detailField: string;
    detailValue: string;
};
export default styles;
//# sourceMappingURL=CrscPrompts.module.scss.d.ts.map
import { Version } from '@microsoft/sp-core-library';
import { type IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';
export interface ICrscPromptsWebPartProps {
    promptListId: string;
    itemsPerPage: number;
    modalMinWidth: number;
    clearAllButtonColor: string;
    cardBorderColor: string;
    cardTitleColor: string;
    viewButtonTextColor: string;
    viewButtonBackgroundColor: string;
}
export default class CrscPromptsWebPart extends BaseClientSideWebPart<ICrscPromptsWebPartProps> {
    private _service;
    private _listOptions;
    private _listLoadError;
    render(): void;
    protected onInit(): Promise<void>;
    protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void;
    protected onPropertyPaneConfigurationStart(): void;
    private toDropdownOptions;
    private getPositiveNumber;
    private getHexColor;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=CrscPromptsWebPart.d.ts.map
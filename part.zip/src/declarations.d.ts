declare module '*.module.scss';

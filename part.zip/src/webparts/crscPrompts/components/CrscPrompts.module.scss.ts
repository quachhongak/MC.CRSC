/* tslint:disable */
require("./CrscPrompts.module.css");
const styles = {
  crscPrompts: 'crscPrompts_fed9907f',
  filterPanel: 'filterPanel_fed9907f',
  searchRow: 'searchRow_fed9907f',
  filterRow: 'filterRow_fed9907f',
  resultsBar: 'resultsBar_fed9907f',
  pagination: 'pagination_fed9907f',
  searchBox: 'searchBox_fed9907f',
  filtersLabel: 'filtersLabel_fed9907f',
  filterDropdown: 'filterDropdown_fed9907f',
  sortGroup: 'sortGroup_fed9907f',
  sortDropdown: 'sortDropdown_fed9907f',
  bottomPagination: 'bottomPagination_fed9907f',
  pageButton: 'pageButton_fed9907f',
  promptGrid: 'promptGrid_fed9907f',
  promptCard: 'promptCard_fed9907f',
  deliverableTag: 'deliverableTag_fed9907f',
  promptTitle: 'promptTitle_fed9907f',
  promptContent: 'promptContent_fed9907f',
  paddingBottomMedium: 'paddingBottomMedium_fed9907f',
  viewButton: 'viewButton_fed9907f',
  configureButton: 'configureButton_fed9907f',
  statusMessage: 'statusMessage_fed9907f',
  promptDetails: 'promptDetails_fed9907f',
  detailField: 'detailField_fed9907f',
  detailValue: 'detailValue_fed9907f'
};

export default styles;
/* tslint:enable */